<template>
    <div><h1><center>Error, page</center></h1></div>
</template>